<template v-for="(todo, index) in todos" :key="index">
  <v-item>
    <v-list-item-content>
      <v-list-item-title>{{ index + 1 }}</v-list-item-title>
      <v-list-item-subtitle>{{ todo }}</v-list-item-subtitle>
    </v-list-item-content>
  </v-item>
</template>

<script>
export default {
  name: 'TodoItem',
  props: {
    todos: Array,
  },
}
</script>
