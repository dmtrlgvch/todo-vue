<template>
  <v-container>
    <v-row>
      <v-col cols="4">
        <p>{{ todos }}</p>
        <v-textarea
          v-model="todoText"
          outlined
          name="input-7-4"
          label="What do you want to do?"
          value=""
        ></v-textarea>
        <v-btn
          @click="addTodo"
          color="primary"
          elevation="2"
          large
        >
          Submit
        </v-btn>
      </v-col>
      <v-col cols="8">
        <TodoList :todos='todos'/>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
  import TodoList from '@/components/TodoList.vue'

  export default {
    name: 'Main',
    components: {
      TodoList
    },
    data() {
      return {
        todoText: '',
        todos: []
      }
    },
    methods: {
      addTodo() {
        if(!this.todoText) {
          return
        }
        this.todos.push(this.todoText)
        this.todoText = ''
      }
    }
  }
</script>
