<template>
  <v-list v-if="todos.length" :todos='todos'>
    <TodoItem />
  </v-list>
</template>

<script>
import TodoItem from './TodoItem'

export default {
  name: 'TodoList',
  props: {
    todos: Array,
  },
  components: {
    TodoItem
  }
}
</script>
